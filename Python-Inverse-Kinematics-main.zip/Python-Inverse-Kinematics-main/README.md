# Python-Inverse-Kinematics
A simple python inverse kinematics algorithm.

*Made by ultimatech*

**2022**
